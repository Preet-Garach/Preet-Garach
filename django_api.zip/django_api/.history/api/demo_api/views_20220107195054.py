from django.shortcuts import render

# Create your views here.
def client(request):
    return "<h1>jfsldkjf</h1>"