from django.shortcuts import render

# Create your views here.
def client(request):
    render ("<h1>jfsldkjf</h1>")