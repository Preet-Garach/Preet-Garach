from django.db.models import fields
from rest_framework import serializers
from . models import client,project,user

class clientSerializer(serializers.ModelSerializer):
    class Meta:
        model = client
        fields=('client_id', 'client_name', 'created_at','created_by')
    
class projectSerializer(serializers.ModelSerializer):
    class Meta:
        model=project
        fields=('project_id', 'project_name', 'created_at','created_by')

class userSerializer(serializers.ModelSerializer):
    class Meta:
        model=user
        fields='__all__'