from django.contrib import admin
from . models import client,user,projects
# Register your models here.
admin.register(client,user,projects)(admin.ModelAdmin)
