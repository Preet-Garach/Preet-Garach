from re import T
from django.http.response import HttpResponse
from django.shortcuts import render
from rest_framework.views import APIView
from . models import client,project,user
from rest_framework.response import Response
from rest_framework import viewsets, status
from . serializer import clientSerializer, projectSerializer,userSerializer

# Create your views here.
class clientList(APIView):
    def get(self,request):
        client_list= client.objects.all()
        serialize=clientSerializer(client_list, many=True)
        return Response(serialize.data)

    def post(self, request):
        data = request.data
        data["created_by"] = "user"
        serializer = clientSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

class clientProjects(APIView):
    def get(self, request, id):
        clientObj = client.objects.filter(client_id=id).get()
        projects = project.objects.filter(client_id=id).values()
        responseObj = {
            'id': clientObj.client_id,
            'client_name': clientObj.client_name,
            'projects':projects,
            'created_at': clientObj.created_at,
            'created_by': clientObj.created_by,
            'updated_at': clientObj.updated_at
        }
        return Response(responseObj, status=status.HTTP_200_OK)

    def put(self, request, id):
        clientObj = client.objects.get(client_id=id)
        clientObj.updated_at = time.now()
        serializer = clientSerializer(clientObj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class projectList(APIView):
    def get(self,request):
        project_list=project.objects.all()
        serialize=projectSerializer(project_list,many=True)
        return Response(serialize.data)

    def post(self, request, id):
        clientId = id
        data = request.data
        data["created_by"] = "creator"

        serializer = projectSerializer(data=request.data)
        if serializer.is_valid():
            clientObj = client.objects.filter(client_id=clientId).get()
            serializer.validated_data["client_id"] = clientObj
            savedProject = serializer.save()
            usersData = data["users"]
            for userObj in usersData:
                u = user.objects.filter(user_id=userObj["id"]).get()
                u.projectId = savedProject.project_id
                u.save()

            responseObj = {
                'users': usersData,
                'id': savedProject.project_id,
                'client': clientObj.client_name,
                'project_name': savedProject.project_name,
                'created_at': savedProject.created_at,
                'created_by': savedProject.created_by
            }
            return Response(responseObj, status=status.HTTP_201_CREATED)

class userList(APIView):
    def get(self,request):
        user_list=user.objects.all()
        serialize=userSerializer(user_list,many=True)
        return Response(serialize.data)