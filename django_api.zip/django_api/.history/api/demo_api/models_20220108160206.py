from django.db import models

# Create your models here.
class user(models.Model):
    user_id=models.AutoField(null=False,primary_key=True)
    user_name=models.CharField(max_length=20,null=False)

class projects(models.Model):
    project_id=models.AutoField(primary_key=True, null=False)
    project_name=models.CharField(null=False)
    created_at=models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=20,null=False)
    user_id=models.ForeignKey(user,on_delete=models.CASCADE)

class client(models.Model):
    client_id=models.AutoField(null=False,primary_key=True)
    client_name=models.CharField(max_length=20,null=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=20,null=False)
    project_id=models.ForeignKey(projects,on_delete=models.CASCADE)


