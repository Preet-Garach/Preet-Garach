from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.
def client(request):
    return HttpResponse("<h1>jfsldkjf</h1>")