from re import T
from django.http.response import HttpResponse
from django.shortcuts import render
from rest_framework.views import APIView
from . models import client,project,user
from rest_framework.response import Response
from . serializer import clientSerializer, projectSerializer,userSerializer
# Create your views here.
class clientList(APIView):
    def get(self,request):
        client_list= client.objects.all()
        serialize=clientSerializer(client_list, many=True)
        return Response(serialize.data)

    def post(self):
        pass

class projectList(APIView):
    def get(self,request):
        project_list=project.objects.all()
        serialize=projectSerializer(project_list,many=True)
        return Response(serialize.data)