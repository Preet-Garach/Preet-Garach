from django.db import models

# Create your models here.
class client(models.Model):
    id=models.IntegerField(null=False,primary_key=True)
    client_name=models.CharField(max_length=20,null=False)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(max_length=20,null=False)

class projects(models.Model):
    id=models.IntegerField(null=False)
    project_name=models.CharField(null=False)
    created_at=models.DateTimeField(auto_now_add=True)
    created_by=models.CharField(null=False)

class user(models.Model):
    id=models.IntegerField(null=False,primary_key=True)
    user_name=models.CharField(max_length=True)
