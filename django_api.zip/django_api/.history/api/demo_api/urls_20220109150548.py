from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('clients',views.clientList.as_view()),
    path('clients/<int:id>/projects',views.projectList.as_view()),
    path('project',views.projectList.as_view()),
    path('user',views.userList.as_view()),
]