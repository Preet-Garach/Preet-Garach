from rest_framework import serializers
from . models import client,project,user

class clientSerializer(serializers.ModelSerializer):
    class Meta:
        model = client
        fields='__all__'
    
class projectSerializer(serializers.ModelSerializer):
    class Meta:
        model='project'
        fields='__all__'

class userSerializer(serializers.ModelSerializer):
    class Meta:
        model='user'
        fields='__all__'