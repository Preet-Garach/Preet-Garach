from django.contrib import admin
from . models import client,user,project
# Register your models here.
admin.register(client,user,project)(admin.ModelAdmin)
