from re import T
from django.http.response import HttpResponse
from django.shortcuts import render
from rest_framework.views import APIView
from . models import client,project,user
from rest_framework.response import Response
from rest_framework import viewsets, status
from . serializer import clientSerializer, projectSerializer,userSerializer

# Create your views here.
class clientList(APIView):
    def get(self,request):
        client_list= client.objects.all()
        serialize=clientSerializer(client_list, many=True)
        return Response(serialize.data)

    def post(self, request):
        data = request.data
        data["created_by"] = "user"
        serializer = clientSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

class projectList(APIView):
    def get(self,request):
        project_list=project.objects.all()
        serialize=projectSerializer(project_list,many=True)
        return Response(serialize.data)

    def post(self, request, id):
        clientId = id
        data = request.data
        data["created_by"] = "creator"
        data["client_id"] = clientId

        serializer = projectSerializer(data=request.data)
        if serializer.is_valid():
            clientObj = client.objects.filter(client_id=clientId)
            serializer.validated_data["client_id"] = clientObj
            savedProject = serializer.save()
            serializer.data["client_name"] = clientObj.client_name
            usersData = data["users"]
            for userObj in usersData:
                print(">>> ", userObj)
                u = user.objects.filter(id=userObj["id"])
                u.projectId = savedProject.id
            return Response(serializer.data, status=status.HTTP_201_CREATED)

class userList(APIView):
    def get(self,request):
        user_list=user.objects.all()
        serialize=userSerializer(user_list,many=True)
        return Response(serialize.data)